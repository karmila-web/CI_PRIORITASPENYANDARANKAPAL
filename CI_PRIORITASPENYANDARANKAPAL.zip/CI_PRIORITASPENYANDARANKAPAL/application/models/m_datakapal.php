<?php 

class M_datakapal extends CI_Model {

    public function tampil_datakapal() {
        return $this->db->get('tb_data_kapal')->result();
    }

    public function input_data($data,$table) {
        $this->db->insert($table,$data);
    }

    public function hapus_datakapal($where, $table) {
        $this->db->where($where);
        $this->db->delete($table);
    } 

    public function edit_datakapal($where, $table) {
        return $this->db->get_where($table,$where);
    }

    public function update_datakapal($where, $data, $table) {
        $this->db->where($where);
        $this->db->update($table,$data);
    }


}

?>