<!-- Footer -->
<footer>
      <!-- Footer bottom -->
      <div class="footer_bottom text-center">
        <p class="wow fadeInRight">
          Made with
          <i class="fa fa-heart"></i>
          by
          <a target="_blank" href="">Karmila. S &</a> <a target="_blank" href="">Sulmiati</a>
          2022
        </p>
      </div>
      <!-- Footer bottom end -->
    </footer>

    <!-- Footer end -->

    <!-- JavaScript -->
    <script src="<?= base_url() ?>assets/js/jquery-1.12.1.min.js"></script>
    <script src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>

    <!-- Bootsnav js -->
    <script src="<?= base_url() ?>assets/js/bootsnav.js"></script>

    <!-- JS Implementing Plugins -->
    <script src="<?= base_url() ?>assets/js/isotope.js"></script>
    <script src="<?= base_url() ?>assets/js/isotope-active.js"></script>
    <script src="<?= base_url() ?>assets/js/jquery.fancybox.js?v=2.1.5"></script>

    <script src="<?= base_url() ?>assets/js/jquery.scrollUp.min.js"></script>

    <script src="<?= base_url() ?>assets/js/main.js"></script>
    <!-- </body>
</html> -->