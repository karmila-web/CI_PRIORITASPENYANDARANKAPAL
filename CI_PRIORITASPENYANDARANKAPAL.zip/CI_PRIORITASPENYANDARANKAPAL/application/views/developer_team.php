    <!-- Team Section -->
    <section id="team">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <br> <br>
                    <h2 class="section-heading">Developer Team</h2><br><br>
                    <h3 class="section-subheading text-muted"></h3>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-5">
                    <div class="team-member">
                        <img src="<?= base_url() ?>assets/images/team/Mila1.jpg" class="img-responsive img-circle" alt=""><br>
                        <h4 align='center'>Karmila. S</h4>
                        <ul align='center' class="list-inline footer_social_icon">
                            <li><a href="https://www.facebook.com/profile.php?id=100013290432531"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://instagram.com/kmila5331?igshid=YmMyMTA2M2Y="><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://wa.me/qr/QIM7WUER3A2QG1"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
                        </ul>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="team-member">
                        <img src="<?= base_url() ?>assets/images/team/Asty.jpg" class="img-responsive img-circle" alt=""><br>
                        <h4 align='center'>Sulmiati</h4>
                        <ul align='center' class="list-inline footer_social_icon">
                            <li><a href="https://www.facebook.com/sulmiati.asti"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://instagram.com/sulmiati_usman?igshid=YmMyMTA2M2Y="><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://wa.me/qr/3PM3M25UGVL5H1"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
                        </ul>
                    </div>
                </div>
              
            </div>
        </div>
    </section>
<br><br><br><br><br>
 <!-- End Team Section -->

 

     